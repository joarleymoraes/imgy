import os

AWS_REGION = os.environ.get('AWS_REGION')

BUCKET = ""

CACHE_MAX_AGE = 3600

DEFAULT_QUALITY_RATE = 80

LOSSY_IMAGE_FMTS = ('jpg', 'jpeg', 'webp')


