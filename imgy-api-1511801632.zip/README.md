# imgy
Serverless Image Processing Service

### Docs:

[http://www.99serverless.com/index.php/2017/11/25/building-a-serverless-image-processing-saas/](http://www.99serverless.com/index.php/2017/11/25/building-a-serverless-image-processing-saas/)
